//Creado con Ardora - www.webardora.net
//bajo licencia Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)
//para otros usos contacte con el autor
var timeAct=280; timeIni=280; timeBon=0;
var successes=0; successesMax=1; attempts=0; attemptsMax=3;
var score=0; scoreMax=1; scoreInc=1; scoreDec=1;
var typeGame=0;
var tiTime=true;
var tiTimeType=1;
var tiButtonTime=true;
var textButtonTime="Comenzar";
var tiSuccesses=true;
var tiAttempts=true;
var tiScore=false;
var startTime; var tiAudio=false;
var colorBack="#FFFDFD"; colorButton="#185B67"; colorText="#000000"; colorSele="#FF8000";
var goURLNext=false; goURLRepeat=false;tiAval=false;
var scoOk=0; scoWrong=0; scoOkDo=1; scoWrongDo=1; scoMessage=""; scoPtos=10;
var fMenssage="Verdana, Geneva, sans-serif";
var fActi="Verdana, Geneva, sans-serif";
var fDefs="Verdana, Geneva, sans-serif";
var fEnun="Verdana, Geneva, sans-serif";
var timeOnMessage=5; messageOk="Felicidades buen trabajo!"; messageTime="Se ha acabado el tiempo , Vuelve a intentarlo"; messageError=""; messageErrorG=""; messageAttempts="Se termino el tiempo , Vuelve a intentarlo"; isShowMessage=false;
var urlOk=""; urlTime=""; urlError=""; urlAttempts="";
var goURLOk="_blank"; goURLTime="_blank"; goURLAttempts="_blank"; goURLError="_blank"; 
borderOk="#008000"; borderTime="#FF0000";borderError="#FF0000"; borderAttempts="#FF0000";
var wordsGame="Q3J1Y2lncmFtYV8tX0JyZW5kYV9QaW5vYXJnb3Rl"; wordsStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function giveZindex(typeElement){var valueZindex=0; capas=document.getElementsByTagName(typeElement);
for (i=0;i<capas.length;i++){if (parseInt($(capas[i]).css("z-index"),10)>valueZindex){valueZindex=parseInt($(capas[i]).css("z-index"),10);}}return valueZindex;}
var col=0; row=0; writeDir=0;
var cw=[["Rw==","","","","","","","","","","","","","",""],["RQ==","TA==","Uw==","RQ==","","","","","","","","","","",""],["VA==","","","","","","","SA==","","","","","","",""],["VA==","","","","QQ==","Qg==","SQ==","RQ==","Ug==","VA==","Tw==","","","",""],["RQ==","","","","","","","Ug==","","","Qg==","","","",""],["Ug==","","","","","","RA==","RQ==","Rg==","","Sg==","","","",""],["Uw==","","","","","","","Tg==","","","RQ==","","","",""],["WQ==","","","","","","","Qw==","","","VA==","","","",""],["Uw==","","","","","","","SQ==","","","Tw==","","","",""],["RQ==","","","","Rg==","TA==","Tw==","QQ==","VA==","","Uw==","VQ==","UA==","RQ==","Ug=="],["VA==","","","","","","","","","","","","Ug==","","RQ=="],["VA==","","","","","","","","","","","","SQ==","","VA=="],["RQ==","","","","","","","","","","","","Tg==","","VQ=="],["Ug==","","","","","","","","","","SQ==","Tg==","VA==","","Ug=="],["Uw==","","","","","","","","","","Rg==","","","","Tg=="]];
var x1=[1,8,13,15,11,1,5,11,5,7,11,11];
var y1=[1,3,10,10,14,2,10,10,4,6,14,4];
var x2=[1,8,13,15,11,4,9,15,11,9,13,11];
var y2=[15,10,14,15,15,2,10,10,4,6,14,10];
var imaCW=["","","","","","","","","Crucigrama_-_Brenda_Pinoargote_resources/media/Pythonlogo.jpg","","",""];
var audioCW=["","","","","","","","","","","",""];
var defCW=["Métodos para leer y escribir variables miembros de la clase sin alterarlas directamente","Proceso que permite compartir los mismos atributos y métodos de una clase","Función que permite imprimir una cadena de texto","Palabra reservada que retorna un valor","Condicional verdadera","Condicional falsa en Python","Tipo de datos utilizados para emplear números reales en una variable","Palabra reservada para referirnos a la clase padre","Python utiliza código","Palabra reservada que se usa para definir funciones definidas por el usuario","Tipo de datos utilizados para emplear números enteros en una variable","Los arreglos son"];
var colNum=15;
var rowNum=15;
